# ValheimFsr4AA 0.2.1

Рабочий прототип FSR 4 Native AA для Valheim с Vulkan и BepInEx. Адаптер перехватывает TaaComponent.Render основной GameCamera и передаёт сцену через NGX Vulkan input OptiScaler. Игра остаётся на Vulkan; FSR выполняется через существующий interop OptiScaler на отдельном DX12-устройстве. Интерфейс игры не входит в обработку сцены.

Фиксированный вход и выход 2560×1440, без генерации кадров. Выбор FSR выполняется через OptiScaler. F9 включает и выключает адаптер. При ошибке возвращается обычный TAA с сообщением в логе.

## Подтверждённый результат

- RX 9070 XT, Windows 10, Valheim 1.0.20, Unity 6000.0.75f1, BepInEx 5.4.23.5.
- В аппаратном тесте: FSR4 4.1.1 NATIVE-AA 1.00X, 2560×1440, успешные NGX dispatch, submit и fence wait.
- Асимметричная RGB-сцена сохраняет ориентацию; watermark читается правильно.
- Три слота не перезаписывают параметры соседних кадров; обработка с reset=0 проверена.
- Владелец подтвердил нормальную работу игрового мира, движения камеры, телепорта и alt-tab. Это пользовательская проверка, отдельный аппаратный замер этих сценариев не записывался.
- Синтетические тесты проверяют установку, обновление, отказ при неизвестных DLL и восстановление исходного стека.

В 0.2.1 исправлены чередование FSR/TAA, постоянный сброс истории и перевёрнутая watermark. Результаты тестовой сцены: evidence/fix-0.2.1.

## Сборка

Нужны PowerShell, Git, Python 3, .NET SDK, Visual C++ x64 Build Tools и Windows SDK. Сборка проверена с .NET SDK 10.0.103 и MSVC 19.51. Исходники и gitlinks закреплены в sources.lock.json.

Из корня репозитория, с исправленными путями игры и профиля:

```powershell
$deps = Join-Path $PWD 'work'
$game = 'D:\SteamLibrary\steamapps\common\Valheim'
$core = "$env:APPDATA/Thunderstore Mod Manager/DataFolder/Valheim/profiles/Default/BepInEx/core"
.\build.ps1 -GamePath $game -BepInExCore $core -DependencyRoot $deps
.\build-optiscaler.ps1 -DependencyRoot $deps
.\build-adapter.ps1 -Game $game -Core $core -DependencyRoot $deps
.\stage-runtime.ps1 -DependencyRoot $deps
```

Готовый пакет: [packages/ValheimFsr4AA-0.2.1-win-x64.zip](packages/ValheimFsr4AA-0.2.1-win-x64.zip). Скачать через Download raw file и распаковать в отдельную папку. Он содержит собственные DLL, точную проверенную сборку OptiScaler, AMD loader/upscaler, D3D12Core, конфигурацию, установочные скрипты, исходники адаптера и лицензии. Сборка перед установкой не нужна. Игровые DLL и BepInEx не включены. Для собственной сборки используйте команды выше. Полный соответствующий исходный код OptiScaler с закреплёнными зависимостями доступен по инструкциям [DEPENDENCY-SOURCE.md](DEPENDENCY-SOURCE.md).

## Установка и удаление

Закрыть игру. Скрипты рассчитаны на проверенную версию игры и отказываются менять неизвестные файлы. Резервные копии сохраняются в каталоге игры. Перед запуском проверить вывод:

```powershell
python deploy.py check
python deploy.py install
python deploy-adapter.py check
```

При отсутствии конфликтующих компонентов: `python deploy-adapter.py install`. Для проверенного прежнего OptiScaler 0.9.4 и GraphicsOverdrive есть `python switch-stack.py install`: он с резервной копией переименовывает только известную dxgi.dll и меняет ExclusiveControl=false, Scaler=Vanilla. Не запускать его для произвольного другого набора модов. Свои пути можно задать через `--game` и `--profile`.

Запуск: Launch-adapter.cmd или launch-adapter.ps1 с путями. Обычный запуск из менеджера без VF_OPTI_DLL не активирует раннюю загрузку OptiScaler. Для обновления установленной 0.2.0: `python upgrade-adapter.py`.

Откат переключённого стека: Restore-previous.cmd, затем при необходимости `python deploy.py remove`. Если кандидат установлен напрямую, сначала `python deploy-adapter.py remove`. Не удалять резервные копии до проверки восстановления.

## Проверки и ограничения

```powershell
python src/test_preload.py 'D:/SteamLibrary/steamapps/common/Valheim/ValheimFsr4AA-backup-0.1.1/0.bin'
python src/test_adapter_deploy.py
python src/test_switch_stack.py
.\checks/run.ps1 -NgxContext -RuntimePackage runtime-candidate -DependencyRoot work
```

GPU-тест требует закрытой игры и создаёт изолированную тестовую копию сцены из локальной установки. В тесте допускается CPU readback для проверки RGB; в основном адаптере покадрового CPU readback нет.

Тест preload требует исходный globalgamemanagers соответствующей версии. Исторический test_deploy.py принимает три аргумента: каталог прежней диагностики 0.1.0, её профиль и существующий scratch-каталог; для него нужна сохранённая локальная копия этой установки. Все четыре Python-теста пройдены перед подготовкой репозитория; игровые файлы в репозиторий не включены.

Состояния различаются: загрузка адаптера, загрузка OptiScaler, создание input/context, NGX evaluate и фактический FSR4 watermark. Успех NGX сам по себе не доказывает FSR4. Настоящий масштаб подтверждается размерами ресурсов и watermark, не только пресетом.

Ограничения: только 2560×1440 и проверенный набор версий; ожидание fence остаётся синхронным; выходной alpha в тесте повторяет красный канал, RGB проверен. Изменение разрешения вне 2560×1440 возвращает обычный TAA. Прирост FPS не обещается. Отдельные замеры задержки игрового мира, длительный stress test и все комбинации модов не выполнялись.

## Лицензии

Собственный код: MIT, LICENSE. OptiScaler: GPL-3.0, отдельная сборка из https://github.com/optiscaler/OptiScaler на commit из sources.lock.json. Собственный Vulkan/DX12 interop не написан. Заголовки Unity и Vulkan имеют отдельные notices в licenses. NGX headers берутся из закреплённого upstream checkout; NVIDIA runtime не включён. Код kewb и GraphicsOverdrive не копировался.

